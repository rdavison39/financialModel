from datetime import date
from decimal import Decimal

from fastapi.testclient import TestClient

from src.api.main import app
from src.models.portfolio_snapshot import PortfolioSnapshot


def test_manage_snapshots_page_shows_cash_flow_fields(monkeypatch):
    class FakeAccount:
        id = 1
        name = "BMO RRSP"
        brokerage_name = "BMO"
        account_number = "1234"

    class FakeHistoryService:
        def __init__(self, session):
            pass

        def get_accounts(self):
            class Item:
                account_id = 1
                brokerage_name = "BMO"
                account_number = "1234"
                account_name = "BMO RRSP"
                label = "BMO — BMO RRSP"
            return [Item()]

    class FakeSession:
        def __init__(self):
            self.snapshot = PortfolioSnapshot(
                id=7,
                account_id=1,
                snapshot_date=date(2026, 9, 29),
                total_value=Decimal("100000"),
                external_added=Decimal("0"),
                external_withdrawn=Decimal("0"),
            )

        def scalars(self, statement):
            class Result:
                def __init__(self, snapshot):
                    self.snapshot = snapshot
                def all(self):
                    return [self.snapshot]
            return Result(self.snapshot)

        def close(self):
            pass

    monkeypatch.setattr("src.api.main.AccountComparisonHistoryService", FakeHistoryService)
    monkeypatch.setattr("src.api.main.get_session", lambda: FakeSession())

    response = TestClient(app).get("/snapshots")
    assert response.status_code == 200
    assert "$ Added" in response.text
    assert "$ Withdrawn" in response.text
    assert "Save" in response.text

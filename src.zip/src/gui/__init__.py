"""
Financial Model GUI package.
"""
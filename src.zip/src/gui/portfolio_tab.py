"""
Portfolio tab for the Financial Model GUI.
"""

import tkinter as tk
from datetime import date
from decimal import Decimal
from tkinter import messagebox, simpledialog, ttk

from sqlalchemy import select, func

from src.database import get_session
from src.database_init import initialize_database
from src.models.account import Account
from src.models.brokerage import Brokerage
from src.models.portfolio_snapshot import PortfolioSnapshot
from src.models.holding_snapshot import HoldingSnapshot
from src.services.portfolio_service import PortfolioService
from src.services.portfolio_valuation_service import (
    PortfolioValuationService,
)


class PortfolioTab(ttk.Frame):
    """Display current portfolio values."""

    def __init__(self, parent: tk.Misc) -> None:
        super().__init__(parent)

        self.columnconfigure(0, weight=1)
        self.rowconfigure(5, weight=1)

        self._build_ui()

        # Load existing values when the tab is created.
        self.after(100, self._load_current_values)

    # =============================================================
    # UI
    # =============================================================

    def _build_ui(self) -> None:
        """Build the portfolio page."""

        ttk.Label(
            self,
            text="Portfolio",
            font=("Segoe UI", 18, "bold"),
        ).grid(
            row=0,
            column=0,
            sticky="w",
            pady=(0, 15),
        )

        # ---------------------------------------------------------
        # Controls
        # ---------------------------------------------------------

        controls = ttk.Frame(self)

        controls.grid(
            row=1,
            column=0,
            sticky="ew",
            pady=(0, 10),
        )

        ttk.Button(
            controls,
            text="Update Portfolio",
            command=self._update_portfolio,
        ).pack(side="left")

        self.status_label = ttk.Label(
            controls,
            text="",
        )

        self.status_label.pack(
            side="left",
            padx=15,
        )

        # ---------------------------------------------------------
        # Update progress
        # ---------------------------------------------------------

        # Keep update progress on one line.  The valuation service
        # reports the current symbol and X/Y count through the
        # progress callback below.
        self.progress_frame = ttk.Frame(self)

        self.progress_frame.grid(
            row=2,
            column=0,
            sticky="ew",
            pady=(0, 15),
        )

        self.progress_frame.columnconfigure(1, weight=1)

        self.progress_label = ttk.Label(
            self.progress_frame,
            text="Ready",
            font=("Consolas", 10),
        )

        self.progress_label.grid(
            row=0,
            column=0,
            sticky="w",
            padx=(0, 10),
        )

        self.progress_bar = ttk.Progressbar(
            self.progress_frame,
            orient="horizontal",
            mode="determinate",
            maximum=100,
            length=300,
        )

        self.progress_bar.grid(
            row=0,
            column=1,
            sticky="ew",
        )

        # ---------------------------------------------------------
        # Portfolio summary
        # ---------------------------------------------------------

        summary = ttk.LabelFrame(
            self,
            text="Portfolio Summary",
            padding=12,
        )

        summary.grid(
            row=3,
            column=0,
            sticky="ew",
            pady=(0, 15),
        )

        summary.columnconfigure(0, weight=1)
        summary.columnconfigure(1, weight=1)
        summary.columnconfigure(2, weight=1)

        # Total portfolio

        ttk.Label(
            summary,
            text="Total Portfolio:",
            font=("Segoe UI", 12, "bold"),
        ).grid(
            row=0,
            column=0,
            sticky="e",
            padx=(10, 5),
        )

        self.total_value_label = ttk.Label(
            summary,
            text="$0.00",
            font=("Segoe UI", 14, "bold"),
        )

        self.total_value_label.grid(
            row=0,
            column=1,
            sticky="w",
            padx=5,
        )

        # Today

        self.total_change_label = ttk.Label(
            summary,
            text="Today: --",
            font=("Segoe UI", 12, "bold"),
        )

        self.total_change_label.grid(
            row=0,
            column=2,
            sticky="w",
            padx=(15, 5),
        )

        # TSX

        self.tsx_label = ttk.Label(
            summary,
            text="TSX: --",
            font=("Segoe UI", 12, "bold"),
        )

        self.tsx_label.grid(
            row=0,
            column=3,
            sticky="w",
            padx=(15, 10),
        )

        # ---------------------------------------------------------
        # Brokerage summary
        # ---------------------------------------------------------

        brokerage_frame = ttk.LabelFrame(
            self,
            text="Brokerage Summary",
            padding=8,
        )

        brokerage_frame.grid(
            row=4,
            column=0,
            sticky="ew",
            pady=(0, 15),
        )

        brokerage_frame.columnconfigure(0, weight=1)

        # Use two synchronized Treeviews so only the Today column
        # receives the daily-change color.  ttk.Treeview tags apply to
        # an entire row, not an individual cell.
        self.brokerage_tree = ttk.Treeview(
            brokerage_frame,
            columns=("brokerage", "value"),
            show="headings",
            height=3,
        )

        self.brokerage_today_tree = ttk.Treeview(
            brokerage_frame,
            columns=("today",),
            show="headings",
            height=3,
        )

        self.brokerage_tree.heading("brokerage", text="Brokerage")
        self.brokerage_tree.heading("value", text="Current Market Value")
        self.brokerage_today_tree.heading("today", text="Today")

        self.brokerage_tree.column(
            "brokerage",
            width=110,
            minwidth=100,
            stretch=False,
        )
        self.brokerage_tree.column(
            "value",
            width=175,
            minwidth=160,
            anchor="e",
            stretch=False,
        )
        self.brokerage_today_tree.column(
            "today",
            width=175,
            minwidth=160,
            anchor="e",
            stretch=True,
        )

        for tag, foreground in (
            ("today_positive", "green"),
            ("today_negative", "red"),
            ("today_zero", "black"),
        ):
            self.brokerage_today_tree.tag_configure(
                tag,
                foreground=foreground,
            )

        self.brokerage_tree.grid(
            row=0,
            column=0,
            sticky="nsew",
        )
        self.brokerage_today_tree.grid(
            row=0,
            column=1,
            sticky="nsew",
        )

        brokerage_frame.columnconfigure(0, weight=0)
        brokerage_frame.columnconfigure(1, weight=1)

        def scroll_brokerage(*args):
            self.brokerage_tree.yview(*args)
            self.brokerage_today_tree.yview(*args)

        brokerage_scrollbar = ttk.Scrollbar(
            brokerage_frame,
            orient="vertical",
            command=scroll_brokerage,
        )
        brokerage_scrollbar.grid(
            row=0,
            column=2,
            sticky="ns",
        )

        self.brokerage_tree.configure(
            yscrollcommand=brokerage_scrollbar.set,
        )

        def brokerage_mousewheel(event):
            units = -int(event.delta / 120)
            self.brokerage_tree.yview_scroll(units, "units")
            self.brokerage_today_tree.yview_scroll(units, "units")
            return "break"

        self.brokerage_tree.bind("<MouseWheel>", brokerage_mousewheel)
        self.brokerage_today_tree.bind("<MouseWheel>", brokerage_mousewheel)

        # Use two synchronized Treeviews so only the Today column
        # receives the daily-change color.  ttk.Treeview tags apply to
        # an entire row, not an individual cell.
        self.accounts_tree = ttk.Treeview(
            accounts_frame,
            columns=(
                "brokerage",
                "account",
                "name",
                "value",
                "roi",
            ),
            show="headings",
            height=10,
        )

        self.accounts_today_tree = ttk.Treeview(
            accounts_frame,
            columns=("today",),
            show="headings",
            height=10,
        )

        self.accounts_tree.heading("brokerage", text="Brokerage")
        self.accounts_tree.heading("account", text="Account")
        self.accounts_tree.heading("name", text="Name")
        self.accounts_tree.heading("value", text="Current Market Value")
        self.accounts_tree.heading("roi", text="ROI")
        self.accounts_today_tree.heading("today", text="Today")

        self.accounts_tree.column(
            "brokerage",
            width=110,
            minwidth=100,
            stretch=False,
        )
        self.accounts_tree.column(
            "account",
            width=100,
            minwidth=90,
            stretch=False,
        )
        self.accounts_tree.column(
            "name",
            width=100,
            minwidth=80,
            stretch=False,
        )
        self.accounts_tree.column(
            "value",
            width=165,
            minwidth=150,
            anchor="e",
            stretch=False,
        )
        self.accounts_tree.column(
            "roi",
            width=75,
            minwidth=65,
            anchor="e",
            stretch=False,
        )
        self.accounts_today_tree.column(
            "today",
            width=175,
            minwidth=160,
            anchor="e",
            stretch=True,
        )

        for tag, foreground in (
            ("today_positive", "green"),
            ("today_negative", "red"),
            ("today_zero", "black"),
        ):
            self.accounts_today_tree.tag_configure(
                tag,
                foreground=foreground,
            )

        self.accounts_tree.grid(
            row=0,
            column=0,
            sticky="nsew",
        )
        self.accounts_today_tree.grid(
            row=0,
            column=1,
            sticky="nsew",
        )

        accounts_frame.columnconfigure(0, weight=0)
        accounts_frame.columnconfigure(1, weight=1)

        def scroll_accounts(*args):
            self.accounts_tree.yview(*args)
            self.accounts_today_tree.yview(*args)

        accounts_scrollbar = ttk.Scrollbar(
            accounts_frame,
            orient="vertical",
            command=scroll_accounts,
        )
        accounts_scrollbar.grid(
            row=0,
            column=2,
            sticky="ns",
        )

        self.accounts_tree.configure(
            yscrollcommand=accounts_scrollbar.set,
        )

        def accounts_mousewheel(event):
            units = -int(event.delta / 120)
            self.accounts_tree.yview_scroll(units, "units")
            self.accounts_today_tree.yview_scroll(units, "units")
            return "break"

        self.accounts_tree.bind("<MouseWheel>", accounts_mousewheel)
        self.accounts_today_tree.bind("<MouseWheel>", accounts_mousewheel)

        self.accounts_tree.bind(
            "<<TreeviewSelect>>",
            self._sync_account_selection,
        )
        self.accounts_today_tree.bind(
            "<<TreeviewSelect>>",
            self._sync_account_selection,
        )

        self.accounts_tree.bind(
            "<Double-1>",
            self._open_account_holdings,
        )
        self.accounts_today_tree.bind(
            "<Double-1>",
            self._open_account_holdings,
        )

        account_actions = ttk.Frame(accounts_frame)
        account_actions.grid(
            row=1,
            column=0,
            columnspan=2,
            sticky="w",
            pady=(8, 0),
        )

        ttk.Button(
            account_actions,
            text="Change Account Name",
            command=self._change_account_name,
        ).pack(side="left")

    # =============================================================
    # Update
    # =============================================================

    def _update_portfolio(self) -> None:
        """Update all account and consolidated portfolio values."""

        self.status_label.configure(text="Updating...")
        self.progress_bar.configure(value=0)
        self.progress_label.configure(
            text="Updating Portfolio: 0%   0 / 0   Starting..."
        )
        self.update_idletasks()

        try:
            initialize_database()

            session = get_session()

            try:
                service = PortfolioValuationService(
                    session,
                    progress_callback=self._update_progress,
                )

                total_value = service.update_all_accounts()

                # Capture the values calculated by the valuation
                # service while they are still available.
                tsx_change = getattr(
                    service,
                    "tsx_daily_change_percent",
                    None,
                )

            finally:
                session.close()

            self._load_current_values(
                tsx_change=tsx_change
            )

            self.progress_bar.configure(value=100)
            self.progress_label.configure(
                text=(
                    "Updating Portfolio: 100%   Complete   "
                    f"TOTAL: {self._format_currency(total_value)}"
                )
            )

            self.status_label.configure(
                text=(
                    f"Updated: "
                    f"{self._format_currency(total_value)}"
                )
            )

        except Exception as exc:
            self.progress_label.configure(
                text=(
                    "Update failed: "
                    f"{type(exc).__name__}: {exc}"
                )
            )
            self.progress_bar.configure(value=0)

            self.status_label.configure(
                text="Update failed."
            )

            messagebox.showerror(
                "Portfolio Update Error",
                f"{type(exc).__name__}: {exc}",
            )

    def _update_progress(
        self,
        count: int,
        total: int,
        symbol: str,
    ) -> None:
        """Update the single-line portfolio progress display."""
        if total <= 0:
            percent = 0
        else:
            percent = min(100, int(count * 100 / total))

        self.progress_bar.configure(value=percent)
        self.progress_label.configure(
            text=(
                f"Updating Portfolio: {percent}%   "
                f"{count} / {total}   {symbol}"
            )
        )
        self.update_idletasks()

    # =============================================================
    # Load values
    # =============================================================

    def _load_current_values(
        self,
        tsx_change: Decimal | None = None,
    ) -> None:
        """Load today's saved portfolio values."""

        try:
            initialize_database()

            session = get_session()

            try:
                today = date.today()

                # -------------------------------------------------
                # Consolidated value
                # -------------------------------------------------

                consolidated = session.scalar(
                    select(PortfolioSnapshot)
                    .where(
                        PortfolioSnapshot.account_id.is_(None),
                        PortfolioSnapshot.snapshot_date == today,
                    )
                )

                if consolidated is None:
                    self.total_value_label.configure(
                        text="$0.00"
                    )

                    self.total_change_label.configure(
                        text="Today: --"
                    )

                else:
                    self.total_value_label.configure(
                        text=self._format_currency(
                            consolidated.total_value
                        )
                    )

                    total_change, total_percent = (
                        self._calculate_daily_change(
                            None,
                            session=session,
                        )
                    )

                    if total_change is None:
                        self.total_change_label.configure(
                            text="Today: --"
                        )
                    else:
                        self.total_change_label.configure(
                            text=(
                                "Today: "
                                f"{self._format_signed_currency(total_change)} "
                                f"({self._format_percent(total_percent)})"
                            )
                        )

                # -------------------------------------------------
                # TSX
                # -------------------------------------------------

                if tsx_change is not None:
                    self.tsx_label.configure(
                        text=(
                            "TSX: "
                            f"{self._format_percent(tsx_change)}"
                        )
                    )
                else:
                    self.tsx_label.configure(
                        text="TSX: --"
                    )

                # -------------------------------------------------
                # Account values
                # -------------------------------------------------

                rows = session.execute(
                    select(
                        Account,
                        Brokerage.name,
                        PortfolioSnapshot.total_value,
                    )
                    .join(
                        Brokerage,
                        Brokerage.id == Account.brokerage_id,
                    )
                    .join(
                        PortfolioSnapshot,
                        PortfolioSnapshot.account_id
                        == Account.id,
                    )
                    .where(
                        PortfolioSnapshot.snapshot_date == today,
                    )
                    .order_by(
                        Brokerage.name,
                        Account.account_number,
                    )
                ).all()

                self._display_accounts(
                    rows,
                    session,
                    tsx_change,
                )

                # -------------------------------------------------
                # Brokerage values
                # -------------------------------------------------

                self._display_brokerages(
                    session,
                    tsx_change,
                )

            finally:
                session.close()

        except Exception as exc:
            self.status_label.configure(
                text=(
                    f"Unable to load values: "
                    f"{type(exc).__name__}"
                )
            )

    # =============================================================
    # Display accounts
    # =============================================================

    def _display_accounts(
        self,
        rows,
        session,
        tsx_change: Decimal | None,
    ) -> None:
        """Display account values and performance."""

        for tree in (self.accounts_tree, self.accounts_today_tree):
            for item in tree.get_children():
                tree.delete(item)

        for account, brokerage_name, value in rows:
            change, change_percent = self._calculate_daily_change(
                account.id,
                session=session,
            )

            roi = self._calculate_roi(
                account.id,
                value,
                session,
            )

            if change is None:
                today_text = "--"
            else:
                today_text = (
                    f"{self._format_signed_currency(change)} "
                    f"({self._format_percent(change_percent)})"
                )

            if change is None or change == 0:
                today_tag = "today_zero"
            elif change > 0:
                today_tag = "today_positive"
            else:
                today_tag = "today_negative"

            iid = str(account.id)

            self.accounts_tree.insert(
                "",
                "end",
                iid=iid,
                values=(
                    brokerage_name,
                    account.account_number,
                    account.name,
                    self._format_currency(value),
                    self._format_percent(roi),
                ),
            )

            self.accounts_today_tree.insert(
                "",
                "end",
                iid=iid,
                values=(today_text,),
                tags=(today_tag,),
            )

    # =============================================================
    # Display brokerages
    # =============================================================

    def _display_brokerages(
        self,
        session,
        tsx_change: Decimal | None,
    ) -> None:
        """Display consolidated values by brokerage."""

        for tree in (self.brokerage_tree, self.brokerage_today_tree):
            for item in tree.get_children():
                tree.delete(item)

        today = date.today()

        rows = session.execute(
            select(
                Brokerage.id,
                Brokerage.name,
                func.sum(PortfolioSnapshot.total_value),
            )
            .join(
                Account,
                Account.brokerage_id == Brokerage.id,
            )
            .join(
                PortfolioSnapshot,
                PortfolioSnapshot.account_id == Account.id,
            )
            .where(
                PortfolioSnapshot.snapshot_date == today,
            )
            .group_by(
                Brokerage.id,
                Brokerage.name,
            )
            .order_by(
                Brokerage.name,
            )
        ).all()

        for brokerage_id, brokerage_name, value in rows:
            account_ids = session.scalars(
                select(Account.id).where(
                    Account.brokerage_id == brokerage_id
                )
            ).all()

            change = Decimal("0")
            has_change = False

            for account_id in account_ids:
                account_change, _ = self._calculate_daily_change(
                    account_id,
                    session=session,
                )

                if account_change is not None:
                    change += account_change
                    has_change = True

            if not has_change:
                change = None
                change_percent = None
            else:
                current_value = Decimal(str(value or 0))
                previous_close_value = current_value - change

                if previous_close_value == 0:
                    change_percent = Decimal("0")
                else:
                    change_percent = (
                        change
                        / previous_close_value
                        * Decimal("100")
                    )

            if change is None:
                today_text = "--"
            else:
                today_text = (
                    f"{self._format_signed_currency(change)} "
                    f"({self._format_percent(change_percent)})"
                )

            if change is None or change == 0:
                today_tag = "today_zero"
            elif change > 0:
                today_tag = "today_positive"
            else:
                today_tag = "today_negative"

            iid = str(brokerage_id)

            self.brokerage_tree.insert(
                "",
                "end",
                iid=iid,
                values=(
                    brokerage_name,
                    self._format_currency(value),
                ),
            )

            self.brokerage_today_tree.insert(
                "",
                "end",
                iid=iid,
                values=(today_text,),
                tags=(today_tag,),
            )

    # =============================================================
    # Account holdings
    # =============================================================

    def _sync_account_selection(self, event=None) -> None:
        """Keep the two account Treeviews selected on the same row."""
        if event is None:
            return

        selected = event.widget.selection()
        if not selected:
            return

        iid = selected[0]
        other = (
            self.accounts_today_tree
            if event.widget is self.accounts_tree
            else self.accounts_tree
        )

        if other.selection() != (iid,):
            other.selection_set(iid)
            other.focus(iid)

    def _open_account_holdings(self, event=None) -> None:
        """Open the holdings window for the selected account."""

        selected = self.accounts_tree.selection()

        if not selected:
            selected = self.accounts_today_tree.selection()

        if not selected:
            return

        account_id = int(selected[0])
        values = self.accounts_tree.item(selected[0], "values")

        account_number = str(values[1]) if len(values) > 1 else ""
        account_name = str(values[2]) if len(values) > 2 else ""

        session = None

        try:
            initialize_database()
            session = get_session()

            portfolio_service = PortfolioService(session)
            portfolio = portfolio_service.get_latest_portfolio(
                account_id
            )

            if portfolio is None:
                messagebox.showinfo(
                    "Account Holdings",
                    "No imported holdings were found for this account.",
                )
                return

            holdings_window = tk.Toplevel(self)
            holdings_window.title(
                f"Account Holdings - {account_number}"
            )
            holdings_window.geometry("1450x700")
            holdings_window.minsize(1100, 550)

            self._build_account_holdings_window(
                holdings_window,
                account_number,
                account_name,
                portfolio,
            )

        except Exception as exc:
            messagebox.showerror(
                "Account Holdings",
                f"Unable to load account holdings:\n\n"
                f"{type(exc).__name__}: {exc}",
            )
        finally:
            if session is not None:
                session.close()

    def _build_account_holdings_window(
        self,
        window: tk.Toplevel,
        account_number: str,
        account_name: str,
        portfolio,
    ) -> None:
        """Build the account holdings window."""

        window.columnconfigure(0, weight=1)
        window.rowconfigure(2, weight=1)

        header = ttk.Frame(window)
        header.grid(
            row=0,
            column=0,
            sticky="ew",
            padx=15,
            pady=(15, 10),
        )

        ttk.Label(
            header,
            text=(
                f"Account {account_number}"
                + (f" - {account_name}" if account_name else "")
            ),
            font=("Segoe UI", 16, "bold"),
        ).pack(side="left")

        ttk.Label(
            header,
            text=(
                f"Snapshot: "
                f"{portfolio.snapshot_date.strftime('%Y-%m-%d')}"
            ),
            font=("Segoe UI", 10),
        ).pack(side="right")

        summary = ttk.LabelFrame(
            window,
            text="Account Summary",
            padding=10,
        )
        summary.grid(
            row=1,
            column=0,
            sticky="ew",
            padx=15,
            pady=(0, 10),
        )

        total_market_value = sum(
            (holding.market_value for holding in portfolio.holdings),
            Decimal("0"),
        )

        total_cost = sum(
            (
                holding.average_cost * holding.quantity
                for holding in portfolio.holdings
            ),
            Decimal("0"),
        )

        total_unrealized_gain = sum(
            (
                holding.unrealized_gain
                for holding in portfolio.holdings
            ),
            Decimal("0"),
        )

        total_gain_percent = (
            total_unrealized_gain / total_cost * Decimal("100")
            if total_cost != 0
            else Decimal("0")
        )

        daily_changes = [
            holding.daily_change
            for holding in portfolio.holdings
            if holding.daily_change is not None
        ]
        total_daily_change = (
            sum(daily_changes, Decimal("0"))
            if daily_changes
            else None
        )

        if total_daily_change is None:
            total_daily_change_text = "--"
        else:
            previous_close_value = total_market_value - total_daily_change
            total_daily_change_percent = (
                total_daily_change / previous_close_value * Decimal("100")
                if previous_close_value != 0
                else Decimal("0")
            )
            total_daily_change_text = (
                f"{self._format_signed_currency(total_daily_change)} "
                f"({self._format_percent(total_daily_change_percent)})"
            )

        summary.columnconfigure(1, weight=1)
        summary.columnconfigure(3, weight=1)
        summary.columnconfigure(5, weight=1)
        summary.columnconfigure(7, weight=1)

        summary_items = (
            ("Market Value:", self._format_currency(total_market_value)),
            ("Cost:", self._format_currency(total_cost)),
            (
                "Unrealized Gain:",
                (
                    f"{self._format_signed_currency(total_unrealized_gain)} "
                    f"({self._format_percent(total_gain_percent)})"
                ),
            ),
            ("Today:", total_daily_change_text),
        )

        for column, (label, value) in enumerate(summary_items):
            base = column * 2

            ttk.Label(
                summary,
                text=label,
                font=("Segoe UI", 10, "bold"),
            ).grid(
                row=0,
                column=base,
                sticky="e",
                padx=(5, 5),
            )

            ttk.Label(
                summary,
                text=value,
                font=("Segoe UI", 11, "bold"),
            ).grid(
                row=0,
                column=base + 1,
                sticky="w",
                padx=(0, 20),
            )

        frame = ttk.LabelFrame(
            window,
            text="Holdings",
            padding=8,
        )
        frame.grid(
            row=2,
            column=0,
            sticky="nsew",
            padx=15,
            pady=(0, 15),
        )

        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)

        # ttk.Treeview row tags color the entire row.  Use a main
        # holdings tree plus a synchronized Today tree so that only the
        # Today / Today % cells are colored.
        tree = ttk.Treeview(
            frame,
            columns=(
                "symbol",
                "company",
                "quantity",
                "average_cost",
                "price",
                "market_value",
                "unrealized_gain",
                "unrealized_gain_percent",
            ),
            show="headings",
        )

        today_tree = ttk.Treeview(
            frame,
            columns=(
                "daily_change",
                "daily_change_percent",
            ),
            show="headings",
        )

        headings = {
            "symbol": "Symbol",
            "company": "Company",
            "quantity": "Quantity",
            "average_cost": "Average Cost",
            "price": "Price",
            "market_value": "Market Value",
            "unrealized_gain": "Unrealized Gain",
            "unrealized_gain_percent": "Gain %",
        }

        for column, heading in headings.items():
            tree.heading(column, text=heading)

        today_tree.heading("daily_change", text="Today")
        today_tree.heading("daily_change_percent", text="Today %")

        tree.column("symbol", width=100, minwidth=80, stretch=False)
        tree.column("company", width=260, minwidth=180, stretch=True)
        tree.column(
            "quantity",
            width=120,
            minwidth=100,
            anchor="e",
            stretch=False,
        )
        tree.column(
            "average_cost",
            width=140,
            minwidth=120,
            anchor="e",
            stretch=False,
        )
        tree.column(
            "price",
            width=120,
            minwidth=100,
            anchor="e",
            stretch=False,
        )
        tree.column(
            "market_value",
            width=160,
            minwidth=140,
            anchor="e",
            stretch=False,
        )
        tree.column(
            "unrealized_gain",
            width=170,
            minwidth=150,
            anchor="e",
            stretch=False,
        )
        tree.column(
            "unrealized_gain_percent",
            width=100,
            minwidth=90,
            anchor="e",
            stretch=False,
        )
        today_tree.column(
            "daily_change",
            width=140,
            minwidth=120,
            anchor="e",
            stretch=False,
        )
        today_tree.column(
            "daily_change_percent",
            width=100,
            minwidth=90,
            anchor="e",
            stretch=True,
        )

        for tag, foreground in (
            ("today_positive", "green"),
            ("today_negative", "red"),
            ("today_zero", "black"),
        ):
            today_tree.tag_configure(
                tag,
                foreground=foreground,
            )

        for holding in sorted(
            portfolio.holdings,
            key=lambda item: item.symbol,
        ):
            gain_percent = holding.unrealized_gain_percent
            quantity_text = (
                f"{holding.quantity:,.6f}".rstrip("0").rstrip(".")
            )

            daily_change_text = (
                self._format_signed_currency(holding.daily_change)
                if holding.daily_change is not None
                else "--"
            )
            daily_change_percent_text = (
                self._format_percent(holding.daily_change_percent)
                if holding.daily_change_percent is not None
                else "--"
            )

            if holding.daily_change is None or holding.daily_change == 0:
                today_tag = "today_zero"
            elif holding.daily_change > 0:
                today_tag = "today_positive"
            else:
                today_tag = "today_negative"

            iid = str(holding.symbol)

            tree.insert(
                "",
                "end",
                iid=iid,
                values=(
                    holding.symbol,
                    holding.company_name,
                    quantity_text,
                    self._format_currency(holding.average_cost),
                    self._format_currency(holding.price),
                    self._format_currency(holding.market_value),
                    self._format_signed_currency(
                        holding.unrealized_gain
                    ),
                    self._format_percent(gain_percent),
                ),
            )

            today_tree.insert(
                "",
                "end",
                iid=iid,
                values=(
                    daily_change_text,
                    daily_change_percent_text,
                ),
                tags=(today_tag,),
            )

        tree.grid(
            row=0,
            column=0,
            sticky="nsew",
        )
        today_tree.grid(
            row=0,
            column=1,
            sticky="nsew",
        )

        frame.columnconfigure(0, weight=0)
        frame.columnconfigure(1, weight=1)

        def scroll_holdings(*args):
            tree.yview(*args)
            today_tree.yview(*args)

        scrollbar = ttk.Scrollbar(
            frame,
            orient="vertical",
            command=scroll_holdings,
        )
        scrollbar.grid(
            row=0,
            column=2,
            sticky="ns",
        )

        tree.configure(
            yscrollcommand=scrollbar.set,
        )

        def holdings_mousewheel(event):
            units = -int(event.delta / 120)
            tree.yview_scroll(units, "units")
            today_tree.yview_scroll(units, "units")
            return "break"

        tree.bind("<MouseWheel>", holdings_mousewheel)
        today_tree.bind("<MouseWheel>", holdings_mousewheel)

        close_frame = ttk.Frame(window)
        close_frame.grid(
            row=3,
            column=0,
            sticky="e",
            padx=15,
            pady=(0, 15),
        )

        ttk.Button(
            close_frame,
            text="Close",
            command=window.destroy,
        ).pack(side="right")

    # =============================================================
    # Account name
    # =============================================================

    def _change_account_name(self) -> None:
        """Change and persist the friendly name of the selected account."""
        selected = self.accounts_tree.selection()

        if not selected:
            selected = self.accounts_today_tree.selection()

        if not selected:
            messagebox.showinfo(
                "Change Account Name",
                "Select an account first.",
            )
            return

        account_id = int(selected[0])
        values = self.accounts_tree.item(selected[0], "values")

        if len(values) < 3:
            return

        account_number = str(values[1])
        current_name = str(values[2])

        new_name = simpledialog.askstring(
            "Change Account Name",
            f"Account {account_number}:",
            initialvalue=current_name,
            parent=self,
        )

        if new_name is None:
            return

        new_name = new_name.strip()

        if not new_name:
            messagebox.showwarning(
                "Change Account Name",
                "The account name cannot be blank.",
            )
            return

        session = None

        try:
            initialize_database()
            session = get_session()

            account = session.scalar(
                select(Account).where(Account.id == account_id)
            )

            if account is None:
                raise ValueError(
                    f"Account ID {account_id} was not found."
                )

            account.name = new_name
            session.commit()

            updated_values = list(values)
            updated_values[2] = new_name

            self.accounts_tree.item(
                selected[0],
                values=updated_values,
            )

        except Exception as exc:
            if session is not None:
                session.rollback()

            messagebox.showerror(
                "Change Account Name",
                f"Unable to save account name:\n\n"
                f"{type(exc).__name__}: {exc}",
            )

        finally:
            if session is not None:
                session.close()

    # =============================================================
    # Daily change
    # =============================================================

    def _calculate_daily_change(
        self,
        account_id: int | None,
        session=None,
    ) -> tuple[Decimal | None, Decimal | None]:
        """Return the brokerage-reported daily change.

        The imported HoldingSnapshot.daily_change is the source of truth.
        For an account, use that account's latest imported snapshot date.
        For the consolidated portfolio, sum the latest imported value for
        each account.

        A portfolio with no security holdings has a daily change of zero.
        """

        own_session = False

        if session is None:
            initialize_database()
            session = get_session()
            own_session = True

        try:
            if account_id is None:
                account_ids = session.scalars(
                    select(Account.id).order_by(Account.id)
                ).all()

                total_change = Decimal("0")
                found_account = False

                for current_account_id in account_ids:
                    change, _ = self._calculate_daily_change(
                        current_account_id,
                        session=session,
                    )
                    if change is not None:
                        total_change += change
                        found_account = True

                if not found_account:
                    return None, None

                # Use the consolidated current PortfolioSnapshot as the
                # denominator for the displayed percentage.
                current = session.scalar(
                    select(PortfolioSnapshot)
                    .where(
                        PortfolioSnapshot.account_id.is_(None),
                        PortfolioSnapshot.snapshot_date == date.today(),
                    )
                )

                if current is None:
                    return total_change, Decimal("0")

                current_value = Decimal(str(current.total_value))
                previous_close_value = current_value - total_change

                percent = (
                    total_change / previous_close_value * Decimal("100")
                    if previous_close_value != 0
                    else Decimal("0")
                )

                return total_change, percent

            current = session.scalar(
                select(PortfolioSnapshot)
                .where(
                    PortfolioSnapshot.account_id == account_id,
                    PortfolioSnapshot.snapshot_date == date.today(),
                )
            )

            if current is None:
                return None, None

            # HoldingSnapshot.snapshot_date is a Date column.  Match the
            # latest imported snapshot exactly rather than comparing a Date
            # column to datetime boundaries.
            latest_snapshot_date = session.scalar(
                select(HoldingSnapshot.snapshot_date)
                .where(
                    HoldingSnapshot.account_id == account_id,
                )
                .order_by(
                    HoldingSnapshot.snapshot_date.desc()
                )
                .limit(1)
            )

            if latest_snapshot_date is None:
                # Cash-only account: no securities means no security daily
                # movement, so display zero rather than "--".
                change = Decimal("0")
            else:
                change_value = session.scalar(
                    select(func.sum(HoldingSnapshot.daily_change))
                    .where(
                        HoldingSnapshot.account_id == account_id,
                        HoldingSnapshot.snapshot_date
                        == latest_snapshot_date,
                    )
                )

                # If all security daily changes are NULL, there is no
                # reported security movement for this snapshot.
                change = (
                    Decimal(str(change_value))
                    if change_value is not None
                    else Decimal("0")
                )

            current_value = Decimal(str(current.total_value))
            previous_close_value = current_value - change

            if previous_close_value == 0:
                percent = Decimal("0")
            else:
                percent = (
                    change
                    / previous_close_value
                    * Decimal("100")
                )

            return change, percent

        finally:
            if own_session:
                session.close()


    # =============================================================
    # ROI
    # =============================================================

    def _calculate_roi(
        self,
        account_id: int,
        current_value: Decimal,
        session,
    ) -> Decimal:
        """
        Calculate account ROI.

        ROI = (ending value - starting value)
              / starting value
        """

        first_snapshot = session.scalar(
            select(PortfolioSnapshot)
            .where(
                PortfolioSnapshot.account_id
                == account_id,
            )
            .order_by(
                PortfolioSnapshot.snapshot_date.asc()
            )
            .limit(1)
        )

        if first_snapshot is None:
            return Decimal("0")

        starting_value = Decimal(
            str(first_snapshot.total_value)
        )

        if starting_value == 0:
            return Decimal("0")

        current_value = Decimal(
            str(current_value)
        )

        return (
            (
                current_value
                - starting_value
            )
            / starting_value
            * Decimal("100")
        )

    # =============================================================
    # Progress
    # =============================================================

    def _write_progress(self, message: str) -> None:
        """Display a final/status message on the single progress line."""
        self.progress_label.configure(text=message)
        self.update_idletasks()

    # =============================================================
    # Formatting
    # =============================================================

    @staticmethod
    def _format_currency(
        value: Decimal,
    ) -> str:
        """Format a Decimal as Canadian currency."""

        return (
            f"${Decimal(str(value)):,.2f}"
        )

    @staticmethod
    def _format_signed_currency(
        value: Decimal,
    ) -> str:
        """Format a signed currency value."""

        value = Decimal(str(value))

        if value >= 0:
            return f"+${value:,.2f}"

        return f"-${abs(value):,.2f}"

    @staticmethod
    def _format_percent(
        value: Decimal | None,
    ) -> str:
        """Format a percentage."""

        if value is None:
            return "--"

        value = Decimal(str(value))

        return f"{value:+.2f}%"

    # =============================================================
    # Standalone entry point
    # =============================================================


def main() -> None:
    """Run the portfolio tab standalone."""

    root = tk.Tk()
    root.title("Financial Model - Portfolio")
    root.geometry("1550x900")
    root.minsize(1200, 700)

    PortfolioTab(root).pack(
        fill="both",
        expand=True,
        padx=15,
        pady=15,
    )

    root.mainloop()


if __name__ == "__main__":
    main()